
document.addEventListener("DOMContentLoaded", () => {
  console.log("Flower Shop website loaded!");
});
